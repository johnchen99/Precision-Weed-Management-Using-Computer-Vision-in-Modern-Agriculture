
Crop_Weed_Dataset - v1 25-Feb-2021
==============================

This dataset was exported via roboflow.ai on February 25, 2021 at 3:58 PM GMT

It includes 340 images.
Crop-Weed are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Equal probability of one of the following 90-degree rotations: none, clockwise, counter-clockwise, upside-down
* Random brigthness adjustment of between -30 and +30 percent


